import sys
from math import *

x = float(sys.argv[2])
y = float( sys.argv[3])

print(eval(sys.argv[1]))